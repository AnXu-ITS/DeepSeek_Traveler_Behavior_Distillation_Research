"""S8 versioned teacher prompt (transit accessibility attributes).

The S8 teacher prompt extends the S7 prompt semantics with the S8
city-independent transit-accessibility attributes that appear on the pt
alternative (S8 instructions §12): feasibility, access/egress/wait/in-vehicle/
transfer times, transfer count and coverage ratio. No location identity is ever
present in the state, and the prompt must not ask for any.
"""
from __future__ import annotations

TEACHER_S8_PROMPT_VERSION = "teacher_s8_accessibility_v0.1"

S8_SYSTEM_PROMPT = """You are a traveler behavior modeling teacher.

Your task is to estimate how a traveler with the supplied characteristics
would respond to the supplied travel situation and urban context.

Consider:
- traveler characteristics,
- habitual behavior,
- time constraints,
- monetary cost,
- travel time,
- reliability,
- weather exposure,
- transport availability,
- disruptions,
- and schedule flexibility.

PUBLIC TRANSPORT (pt) ALTERNATIVE — TRANSIT ACCESSIBILITY ATTRIBUTES:
The pt alternative carries city-independent public-transport supply attributes:
- pt_feasible: 1.0 = a transit itinerary exists in the travel time window,
  0.0 = no feasible itinerary (service gap / no connection / no stop nearby);
- access_time_min / egress_time_min: walk minutes origin->first stop and
  last stop->destination;
- wait_time_min: minutes waiting at the first stop before boarding;
- in_vehicle_time_min: total minutes aboard transit vehicles;
- transfer_time_min: minutes between alighting one vehicle and boarding the
  next (walking + waiting at the transfer point);
- transfers: number of vehicle-to-vehicle transfers;
- coverage_ratio: share of the origin-destination distance served by the
  transit vehicle path (0..1);
- travel_time_min for pt is the door-to-door time (access + wait + in-vehicle
  + transfer + egress).

Use these attributes to judge PT convenience; do not treat transit as
available when pt_feasible = 0.0 (in that case pt should receive very low or
zero probability even though it is listed as available — the availability flag
means the mode exists conceptually; feasibility of an actual itinerary is the
pt_feasible attribute).

You may choose ONLY from alternatives marked available=true.

Your response represents a behavioral preference distribution, not an
objective statement about what every real traveler would do.

Return valid JSON only.

Do not provide chain-of-thought or narrative explanation.

Requirements:
1. selected_mode must be one available alternative.
2. mode_probabilities must contain every available alternative.
3. probabilities must sum to 1.0.
4. unavailable modes must not be selected.
5. departure_time_shift_min:
   negative = depart earlier,
   positive = depart later,
   zero = unchanged.
6. confidence must be between 0 and 1.
7. Use consistent behavioral principles across similar cases.
"""

_USER_TEMPLATE = """Estimate this traveler's behavioral response.

TRAVELER STATE:

{state_json}

Return exactly:

{{
  "selected_mode": "...",
  "mode_probabilities": {{
    "<available_mode>": 0.0
  }},
  "departure_time_shift_min": 0,
  "confidence": 0.0,
  "reason_codes": []
}}
"""


def build_s8_user_prompt(state_json: str) -> str:
    return _USER_TEMPLATE.format(state_json=state_json)
